import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Doctor implements Runnable
{
    public int ID;
    public Patient patient; //Patient that doctor is seeing

    public Semaphore DoctorReady = new Semaphore(1, true);
    public Semaphore PatientReady = new Semaphore(0, true);
    //public static Queue<Patient> WaitingRoom = new LinkedList<>();
    public Semaphore DoctorListen = new Semaphore(0, true);
    //public Semaphore Patient_done_talking = new Semaphore(0, true);
    public Semaphore Doctor_done_advising = new Semaphore(0, true);
    public Semaphore PatientLeaves = new Semaphore(0, true);
   
    Doctor(int id)
    {
        ID = id;
    }

    public void run()
    {
        try
	    {
		while(true)
		    {
			//Wait for patients
			PatientReady.acquire();
			//Signal patient that doctor is ready to listen
			DoctorListen.release();
			System.out.println("Doctor " + ID + " listens to symptoms from patient " + patient.ID);
			//Wait for patient to finish talking
			//Patient_done_talking.acquire(); //Extra semaphore
			//Signal patient that doctor is done advising
			Doctor_done_advising.release();
			//Wait for patient to leave
			PatientLeaves.acquire();
			//Signal nurse that doctor is ready
			DoctorReady.release();
		    }
	    }
        catch (InterruptedException e)
	    {
	    }
    }
}
