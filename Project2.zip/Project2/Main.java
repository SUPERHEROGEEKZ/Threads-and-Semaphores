import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Main
{
    public static void main(String[] args) {
	int Num_Doctors = 0;
	int Num_Patients = 0;
	int Num_Nurses = 0;

	try {
	    if (args.length == 2)
		{
		    int temp = Integer.parseInt(args[0]);
		    Num_Doctors = temp > 3? 3:temp; //ternary operator
		    temp = Integer.parseInt(args[1]);
		    Num_Patients = temp > 30? 30:temp;
		    Num_Nurses = Num_Doctors;
		}
	    else
		{
		    System.err.println("Error!");
		    System.exit(-1);
		}
	    Queue<Patient> PatientQueue = new LinkedList<> (); //Registration queue
	    Semaphore Patients_in_line = new Semaphore(0, true); //Patients waiting for registration                     
	    Semaphore PatientList = new Semaphore(1, true); //Makes sure one thread accesses registration queue at a time
	    Semaphore WaitingLine = new Semaphore(1, true); //Makes sure one thread accesses waiting room queue at a time
	   	  
	    Receptionist tempRecep = new Receptionist(PatientQueue, Patients_in_line, PatientList);
	    Thread receptionist = new Thread(tempRecep);
	    receptionist.start();
	    Thread[] doctors = new Thread[Num_Doctors];
	    Thread[] nurses = new Thread[Num_Nurses];
	    for(int i = 0; i < Num_Doctors; i++)
		{
		    Doctor tempDoc = new Doctor(i);
		    doctors[i] = new Thread(tempDoc);
		    nurses[i] = new Thread(new Nurse(i, tempDoc, tempRecep, WaitingLine));
		}
	    Thread[] patients = new Thread[Num_Patients];
	    for(int i = 0; i < Num_Patients; i++)
		{
		    Patient tempPatient = new Patient(PatientQueue, Patients_in_line, PatientList, i, Nurse.WaitingRoom, Nurse.PatientsWaiting, WaitingLine);
		    patients[i] = new Thread(tempPatient);
		}
	    for(int i = 0; i < doctors.length; i++)
		{		    doctors[i].start();
		    nurses[i].start();
		}
	    for(int i = 0; i < patients.length; i++)
		{
		    patients[i].start();
		}
	    for(int i = 0; i < patients.length; i++) //To see if all patients have been served
		{
		    patients[i].join();
		}
	    receptionist.interrupt();
	    for(int i = 0; i < doctors.length; i++)
		{
		    doctors[i].interrupt();
		    nurses[i].interrupt();
		}
}
	catch (Exception e)
	    {
		System.err.println("Error!");
	    }
    }
}
