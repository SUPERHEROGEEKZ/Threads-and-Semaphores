import java.net.StandardSocketOptions;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Patient implements Runnable
{
    public int ID;
    public Queue<Patient> WaitingRoom;
    public Semaphore PatientsWaiting;
    public Doctor doc;

    private Queue<Patient> PatientQueue;

    private Semaphore Patients_in_line;
    //private static Semaphore WaitingRoomLine = new Semaphore(1, true);

    public Semaphore RegistrationComplete = new Semaphore(0, true);
    public Semaphore Nurse_to_Doctor = new Semaphore(0, true);
    public Semaphore PatientList;
    public Semaphore WaitingLine;

    Patient(Queue<Patient> Queue, Semaphore Patients, Semaphore PatientAccess, int id, Queue<Patient> waiting, Semaphore Patients_in_Waiting, Semaphore Wait)
    {
        PatientQueue = Queue;
        Patients_in_line = Patients;
        ID = id;
        WaitingRoom = waiting;
        PatientsWaiting = Patients_in_Waiting;
	PatientList = PatientAccess;
	WaitingLine = Wait;
    }

    public void run()
    {
        try
	    {
		//Get in queue (signal receptionist)
		PatientList.acquire(); //Waiting to get into queue one by one
		PatientQueue.add(this);
		System.out.println("Patient " + ID + " enters waiting room, waits for receptionist");

                Patients_in_line.release(); //Release = signal                                                                                       
                PatientList.release(); //Signal for other patients to come in line                                                                
		//Wait for receptionist to finish registering
		RegistrationComplete.acquire();
		System.out.println("Patient " + ID + " leaves receptionist and sits in waiting room");
		//Get in waiting room queue (signal receptionist)
		WaitingLine.acquire();
		WaitingRoom.add(this);
		PatientsWaiting.release();
		WaitingLine.release();
		//Wait for nurse to direct to doctor
		Nurse_to_Doctor.acquire();
		//Enter doctor's office (signal that patient is ready)
		System.out.println("Patient " + ID + " enters doctor " + doc.ID + "'s office");
		//See doctor and tell problems (Wait for doctor to listen)
		doc.DoctorListen.acquire();
		//Signal done with problems
		//doc.sem.Patient_done_talking.release(); //Extra Semaphore
		//Wait for doctor's advice
		doc.Doctor_done_advising.acquire();
		System.out.println("Patient " + ID + " receives advice from doctor " + doc.ID);
		//Signal leave with current doctor
		doc.PatientLeaves.release();
		System.out.println("Patient " + ID + " leaves");
	    }
        catch(InterruptedException e)
	    {
	    }
    }
}
