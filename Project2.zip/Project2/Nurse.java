import java.nio.channels.ReadableByteChannel;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Nurse implements Runnable
{
    public int ID;
    public Doctor doctor;
    public Receptionist reception;

    public static Semaphore PatientsWaiting = new Semaphore(0, true); //Patients in waiting room
    //public static Semaphore PatientsLine = new Semaphore(1, true); //Nurse queuing patients
    public static Queue<Patient> WaitingRoom = new LinkedList<>(); //Waiting room queue
    public Semaphore WaitingLine;

    Nurse(int id, Doctor doc, Receptionist recep, Semaphore Wait)
    {
	WaitingLine = Wait;
        ID = id;
        doctor = doc;
        reception = recep;
    }

    public void run()
    {
        try
	    {
		while(true)
		    {
			//Wait for receptionist to be ready
			reception.PatientReady.acquire();
			//Wait for doctor to be ready for patient
			doctor.DoctorReady.acquire();
			//Wait for patients in waiting room
			PatientsWaiting.acquire();
			//Wait to make sure nurse is removing patients one at a time
			WaitingLine.acquire();
			Patient newPatient = WaitingRoom.remove();
			doctor.patient = newPatient; //Assigning patient to doctor (random)
			newPatient.doc = doctor;
			WaitingLine.release(); //Letting other nurses know that they can take in patients
			System.out.println("Nurse " + ID + " takes patient " + newPatient.ID + " to doctor's office");
			//Signal doctor that patient is ready
			doctor.PatientReady.release();
			newPatient.Nurse_to_Doctor.release();
		    }
	    }
        catch (InterruptedException e)
	    {
	    }
    }
}
