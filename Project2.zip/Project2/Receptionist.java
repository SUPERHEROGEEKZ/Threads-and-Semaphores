import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Receptionist implements Runnable
{
    public Queue<Patient> PatientQueue; //Registering queue
    //public Queue<Patient> PatientQueue = new LinkedList<> (); //Registration queue                                                            
    public Semaphore Patients_in_line; //Patients waiting for registration    
    //public Semaphore Patients_in_line = new Semaphore(0, true); //Patients waiting for registration
    public Semaphore PatientReady = new Semaphore(0, true); //Patient is ready for nurse
    public Semaphore PatientList; //

    public Receptionist(Queue<Patient> Patient, Semaphore PatientsLine, Semaphore PatientAccess)
    {
	PatientQueue = Patient;
	Patients_in_line = PatientsLine;
	PatientList = PatientAccess;
    }

    public void run()
    {
        try
	    {
		while(true)
		    {
			//Wait for patients in line
			Patients_in_line.acquire();
			PatientList.acquire();
			//Calls in patient for registration
			Patient newPatient = PatientQueue.remove();
			PatientList.release();
			//Register patient (Signal that registration is complete)
			System.out.println("Receptionist registers patient " + newPatient.ID);
			newPatient.RegistrationComplete.release();
			//Signal nurse that patient is ready
			PatientReady.release();
			//Check for more patients in line and loop
		    }
	    }
        catch(InterruptedException e)
	    {
	    }
    }
}
